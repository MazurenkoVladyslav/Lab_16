function toggleElements() {
    var images = document.querySelectorAll('img');
    
    images.forEach(function(img) {
        if (img.style.display === 'none') {
            img.style.display = 'block';
        } else {
            img.style.display = 'none';
        }
    });
}
